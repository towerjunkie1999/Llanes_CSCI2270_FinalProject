#ifndef HASHTABLE_H
#define HASHTABLE_H
#include <string>
#include <vector>

struct HashElem{
	std::string title;
	int year;
	std::string director;
	int ranking;
	int length;
	std::string genres;
	HashElem *next;
    HashElem *previous;

	HashElem(){};
	HashElem(std::string in_title, int in_year, int in_length, int in_ranking, std::string in_direc, std::string in_genres)
	{
		title = in_title;
		year = in_year;
		length = in_length;
		ranking = in_ranking;
		director = in_direc;
		genres = in_genres;
		next = NULL;
		previous = NULL;
	}

};

class HashTable
{
	public:
		HashTable();
		~HashTable();
		void buildTable();
		void printTableContents();
		void insertMovie(std::string name, int year, int length, int ranking, std::string director, std::string genres);
		void deleteMovie(std::string name);
		void findMovie(std::string name);
		void favoriteMovies();
		HashElem*  findMovieOne(std::string name);
        void searchDate(int max, std::string rand);
		void searchDirector(std::string name, std::string rand);
		void searchLength(int max, std::string rand);
		void searchGenres(std::string type, std::string rand);
		void searchRanking(int min, std::string rand);
		void alikeMovies(std::string name, std::string rand);
		void randomPrint(std::string test, std::vector<HashElem*> array);

	private:
		int hashSum(std::string x, int s);
		int tableSize = 10;
		HashElem* hashTable[10];

};

#endif // HASHTABLE_H
