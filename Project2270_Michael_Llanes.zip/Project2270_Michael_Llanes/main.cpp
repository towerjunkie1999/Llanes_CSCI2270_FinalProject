//Author: Michael Llanes
//Date: 04/25/2016
//Class: CSCI 2270
//Rhonda Hoenigman
//Project

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include "HashTable.h"

using namespace std;

string stringConvert(string strToConvert);

int main(int argc, char* argv[])
{
	HashTable test;
	test.buildTable();
	int userOpt;
	string wanted;
	string movie;
	string rand;
	string director;
	string genre;
	int year;
	int rank;
	int length;
	int brk = 0;

	cout << "        WELCOME TO BUFFALO RECOMMENDATION!" << endl;
	cout << "======================================================" << endl;
	cout << "Here, you can be recommended a movie that is guaranteed " << endl;
	cout << "to be recognized for quality. (Either the IMDb Top 250" << endl;
	cout << "of All Time list, and/or Oscar winners)" << endl;

	while (brk != 1)
	{
		cout << "\n======Main Menu======" << endl;
		cout << "1. Get Recommendation" << endl;
		cout << "2. Insert movie" << endl;
		cout << "3. Find movie" << endl;
		cout << "4. Print table contents" << endl;
		cout << "5. Delete Movie" << endl;
		cout << "6. Quit" << endl;
		cin >> userOpt;

		if (userOpt == 1)
		{
			cout << "How do you want your movies sorted today?\n" << endl;
			cout << "(I) IMDb Ranking?" << endl;
			cout << "(A) Alike Another Title?" << endl;
			cout << "(Y) Year of Release?" << endl;
			cout << "(L) Movie Length?" << endl;
			cout << "(D) Movie's Director?" << endl;
			cout << "(G) Genres of Movie?" << endl;
			cout << "(P) My Personal Recommendations?\n" << endl;
			cout << "Enter the corresponding letter of your preferred categorization?" << endl;
			cin >> wanted;

			if (wanted == "I" || wanted == "i")
			{
				cout << "\nEnter the minimum IMDb rating you would like for a movie (1-100): " << endl;
				cin >> rank;
				cout << "\nFor randomization of results(varied recommendations) please enter any five non-sequential characters:" << endl;
				cin >> rand;
				test.searchRanking(rank, rand);
			}

			else if (wanted == "A" || wanted == "a")
			{
				cout << "Enter a title for a movie you want your movie to be like:" << endl;
				cin.ignore();
				getline(cin, movie);
				cout << "\nFor randomization of results(varied recommendations) please enter any five non-sequential characters:" << endl;
				cin >> rand;
				test.alikeMovies(movie, rand);
			}

			else if (wanted == "Y" || wanted == "y")
			{
				cout << "\nEnter the oldest year you want your movie to be from(1963 would return any movie from 1963 till 2016):" << endl;
				cin >> year;
				cout << "\nFor randomization of results(varied recommendations) please enter any five non-sequential characters:" << endl;
				cin >> rand;
				test.searchDate(year, rand);
			}

			else if (wanted == "L" || wanted == "l")
			{
				cout << "\nEnter the longest you want your movie to be (in minutes):" << endl;
				cin >> length;
				cout << "\nFor randomization of results(varied recommendations) please enter any five non-sequential characters:" << endl;
				cin >> rand;
				test.searchLength(length, rand);
			}

			else if (wanted == "D" || wanted == "d")
			{
				cout << "\nEnter the director whose movies you'd like to view:" << endl;
				cin.ignore();
				getline(cin, director);
				cout << "\nFor randomization of results(varied recommendations) please enter any five non-sequential characters:" << endl;
				cin >> rand;
				test.searchDirector(director, rand);
			}

			else if (wanted == "G" || wanted == "g")
			{
				cout << "\nGenres:      (A) Action                    (W)War" << endl;
				cout << "             (F) Science-Fiction/Fantasy   (R)Romance" << endl;
				cout << "             (D) Drama                     (T)Western" << endl;
				cout << "             (O) Comedy                    (N)Animated" << endl;
				cout << "             (C) Crime                     (Y)Mystery" << endl;
				cout << "\nEnter the corresponding letter of the genre you would like your movie to belong to:" << endl;
				cin >> genre;
				genre = stringConvert(genre);
				cout << "\nFor randomization of results(varied recommendations) please enter any five non-sequential characters:" << endl;
				cin >> rand;
				test.searchGenres(genre, rand);
			}

			else if (wanted == "P" || wanted == "p")
			{
				test.favoriteMovies();
			}
		}

		else if (userOpt == 2)
		{
			cout << "Enter title of movie:" << endl;
			cin.ignore();
			getline(cin, movie);
			cout << "\n";

			cout << "Enter year of release:" << endl;
			cin >> year;
			cout << "\n";

			cout << "Enter length of movie:" << endl;
			cin >> length;
			cout << "\n";

			cout << "Enter director:" << endl;
			cin.ignore();
			getline(cin, director);
			cout << "\n";

			cout << "Enter genres of movies(using letters from genre recommendation):" << endl;
			cin.ignore();
			getline(cin, genre);
			cout << "\n";

			cout << "Enter possible IMDb Top 250 of All Time ranking:" << endl;
			cin >> rank;
			cout << "\n";

			test.insertMovie(movie, year, length, rank, director, genre);
		}

		else if (userOpt == 3)
		{
			cout << "Enter title:" << endl;
			cin.ignore();
			getline(cin, movie);

			cout << "\nRanking, Title, Year, Length, Director, Genres\n" << endl;
			test.findMovie(movie);
		}

		else if (userOpt == 4)
		{
			test.printTableContents();
		}

		else if (userOpt == 5)
		{
			cout << "Enter title:" << endl;
			cin.ignore();
			getline(cin, movie);

			test.deleteMovie(movie);
		}

		else
		{
			cout << "See ya! Sko Buffs!" << endl;
			brk++;
		}
	}
}

string stringConvert(string strToConvert)
{
	std::transform(strToConvert.begin(), strToConvert.end(), strToConvert.begin(), ::toupper);

	return strToConvert;
}