//Author: Michael Llanes
//Date: 04/25/2016
//Class: CSCI 2270
//Rhonda Hoenigman
//Project



#include "HashTable.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <vector>
#include <cstdlib>

using namespace std;


HashTable::HashTable()
{
    for (int i = 0; i < tableSize; i++)
    {
        hashTable[i] = NULL;
    }
}

HashTable::~HashTable()
{
    delete[] hashTable;
}

int HashTable::hashSum(string x, int s)
{
    int sum = 0;
    int length = strlen( x.c_str() );
    for (int i = 0; i < length; i++)
    {
        sum = sum + x[i];
    }
    sum = sum % s;
    return sum;
}

void HashTable::randomPrint(string test, vector<HashElem*> array)
{
    int sum = 0;
    for (int i = 0; i < 5; i++)
    {
        sum = test[i] % array.size();
        cout << (i+1) << ": " << array[sum]->title << ", " << array[sum]->year << ", " << array[sum]->length << ", " << array[sum]->director << ", " << array[sum]->genres << endl;
        sum = 0;
    }
}

void HashTable::printTableContents()
{
    HashElem *sgoinon = new HashElem;
    int brk = 0;
    int count = 0;
    for (int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] == NULL)
        {
            count++;
        }
    }

    if (count == tableSize)
    {
        cout << "empty" << endl;
    }

    else
    {
        for (int i = 0; i < tableSize; i++)
        {
            brk = 0;
            bool what;
            if (hashTable[i] != NULL)
            {
                sgoinon = hashTable[i];
                while(brk == 0)
                {
                    if (sgoinon != NULL)
                    {
                        cout << sgoinon->ranking << ", " << sgoinon->title << ", " << sgoinon->year << ", " << sgoinon->director << ", " << sgoinon->genres << endl;
                        sgoinon = sgoinon->next;
                    }
                    else
                    {
                        brk++;
                    }
                }
            }

            else
            {
                what = false;
            }
        }
    }
}

void HashTable::insertMovie(string name, int year, int length, int ranking, string director, string genres)
{

    int index = hashSum(name, tableSize);
    HashElem *node = new HashElem;
    HashElem *sgoinon = new HashElem;
    int brk = 0;
    node->title = name;
    node->year = year;
    node->length = length;
    node->ranking = ranking;
    node->director = director;
    node->genres = genres;
    node->previous = NULL;
    node->next = NULL;
    if (hashTable[index] == NULL)
    {
        hashTable[index] = node;
    }

    else
    {
        sgoinon = hashTable[index];
        while(brk == 0)
        {
            if (sgoinon->next != NULL)
            {
                sgoinon = sgoinon->next;
            }
            else
            {
                sgoinon->next = node;
                sgoinon->next->previous = sgoinon;
                brk++;
            }
        }
    }

}

void HashTable::deleteMovie(std::string name)
{
    int index = hashSum(name, tableSize);
    HashElem *sgoinon = new HashElem;

    if (hashTable[index] != NULL)
    {
        if (hashTable[index]->title == name)
        {
            if (hashTable[index]->next != NULL)
            {
                HashElem *tmp = hashTable[index];
                hashTable[index] = hashTable[index]->next;
                hashTable[index]->previous = NULL;
                delete tmp;
            }

            else
            {
                hashTable[index] = NULL;
            }
        }
        else
        {
            sgoinon = hashTable[index]->next;
            while(sgoinon != NULL)
            {
                if (sgoinon->title == name)
                {
                    sgoinon->previous->next = sgoinon->next;
                    sgoinon->next->previous = sgoinon->previous;
                    delete sgoinon;

                }
                else
                {
                    sgoinon = sgoinon->next;
                }
            }
        }
    }
}

void  HashTable::findMovie(string name)
{
    int index = hashSum(name, tableSize);
    HashElem *sgoinon = new HashElem;

    if (hashTable[index] != NULL)
    {
        if (hashTable[index]->title == name)
        {
            sgoinon = hashTable[index];
            cout << sgoinon->ranking << ", " << sgoinon->title << ", " << sgoinon->year << ", " << sgoinon->director << ", " << sgoinon->genres << endl;
        }
        else
        {
            sgoinon = hashTable[index]->next;
            while(sgoinon != NULL)
            {
                if (sgoinon->title == name)
                {
                    cout << sgoinon->ranking << ", " << sgoinon->title << ", " << sgoinon->year << ", " << sgoinon->director << ", " << sgoinon->genres << endl;
                    sgoinon = NULL;
                }
                else
                {
                    sgoinon = sgoinon->next;
                }
            }
        }
    }

    else
    {
        cout << "not found" << endl;
    }
}

void HashTable::favoriteMovies()
{
    string favs[10] = {"Snatch", "Fargo", "City of God", "Taxi Driver",
                        "Interstellar", "For a Few Dollars More", "Raging Bull",
                        "Django Unchained", "Rashomon", "The Big Lebowski"};

    for(int i = 0; i < 10; i++)
    {
        findMovie(favs[i]);
    }
}

void HashTable::buildTable()
{
    ifstream inFile;
    inFile.open("Titles.txt");
    string data;
    int c;
    string value;
    string title;
	int year;
	string director;
	int ranking;
	int length;
	string genres;

    if(inFile.good())
    {
        while(getline(inFile, data))
        {
            c = 0;
            istringstream line(data);
            while(getline(line, value, ','))
            {
                if (c == 0)
                {
                    ranking = atoi(value.c_str());
                }

                else if (c == 1)
                {
                    title = value;
                }
                else if (c == 2)
                {
                    year = atoi(value.c_str());
                }
                else if (c == 3)
                {
                    length = atoi(value.c_str());
                }
                else if (c == 4)
                {
                    director = value;
                }
                else if (c == 5)
                {
                    genres = value;
                }
                c++;
            }
            insertMovie(title, year, length, ranking, director, genres);
        }
    }
}
HashElem*  HashTable::findMovieOne(string name)
{
    int index = hashSum(name, tableSize);
    HashElem *sgoinon = new HashElem;

    if (hashTable[index] != NULL)
    {
        if (hashTable[index]->title == name)
        {
            return hashTable[index];
        }
        else
        {
            sgoinon = hashTable[index]->next;
            while(sgoinon != NULL)
            {
                if (sgoinon->title == name)
                {
                    return sgoinon;
                    sgoinon = NULL;
                }
                else
                {
                    sgoinon = sgoinon->next;
                }
            }
        }
    }

    else
    {
        cout << "not found" << endl;
    }
    return NULL;// This will fix a lot of problems
}

void HashTable::searchDate(int max, string rand)
{
    vector<HashElem*> listedMovies;
    HashElem *node = new HashElem;
    for(int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] != NULL)
        {
            node = hashTable[i];
            while(node->next != NULL)
            {
                if (node->year >= max)
                {
                    listedMovies.push_back(node);
                    node = node->next;
                }

                else
                {
                    node = node->next;
                }
            }
        }
    }

    randomPrint(rand, listedMovies);
}

void HashTable::searchDirector(string name, string rand)
{
    vector<HashElem*> listedMovies;
    HashElem *node = new HashElem;
    for(int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] != NULL)
        {
            node = hashTable[i];
            while(node->next != NULL)
            {
                if (node->director == name)
                {
                    listedMovies.push_back(node);
                    node = node->next;
                }

                else
                {
                    node = node->next;
                }
            }
        }
    }

    randomPrint(rand, listedMovies);
}

void HashTable::searchRanking(int min, string rand)
{
    vector<HashElem*> listedMovies;
    HashElem *node = new HashElem;
    for(int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] != NULL)
        {
            node = hashTable[i];
            while(node->next != NULL)
            {
                if (node->ranking <= min && node->ranking != 0)
                {
                    listedMovies.push_back(node);
                    node = node->next;
                }

                else
                {
                    node = node->next;
                }
            }
        }
    }
    randomPrint(rand, listedMovies);
}

void HashTable::searchLength(int max, string rand)
{
    vector<HashElem*> listedMovies;
    HashElem *node = new HashElem;
    for(int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] != NULL)
        {
            node = hashTable[i];
            while(node->next != NULL)
            {
                if (node->length <= max)
                {
                    listedMovies.push_back(node);
                    node = node->next;
                }

                else
                {
                    node = node->next;
                }
            }
        }
    }
    randomPrint(rand, listedMovies);
}

void HashTable::searchGenres(std::string type, std::string rand)
{
    vector<HashElem*> listedMovies;
    HashElem *node = new HashElem;
    for(int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] != NULL)
        {
            node = hashTable[i];
            while(node->next != NULL)
            {
                if (strstr(node->genres.c_str(), type.c_str()))
                {
                    listedMovies.push_back(node);
                    node = node->next;
                }
                else
                {
                    node = node->next;
                }
            }
        }
    }
    randomPrint(rand, listedMovies);
}

void HashTable::alikeMovies(std::string name, std::string rand)
{
    vector<HashElem*> listedMovies;
    HashElem *node = new HashElem;
    HashElem *result = findMovieOne(name);
    if(result == NULL)
    {
        cout<<endl;
        cout<<"Inputed movie not found."<<endl;
        return;
    }
    string genre = result->genres;
    int length = strlen( genre.c_str() );

    for(int i = 0; i < tableSize; i++)
    {
        if (hashTable[i] != NULL)
        {
            node = hashTable[i];
            for (int j = 0; j < length; j++)
            {
                while(node->next != NULL)
                {
                    if (strstr(node->genres.c_str(), &genre[j]))
                    {
                        listedMovies.push_back(node);
                        node = node->next;
                    }
                    else
                    {
                        node = node->next;
                    }
                }
            }
        }
    }

    randomPrint(rand,listedMovies);
}
